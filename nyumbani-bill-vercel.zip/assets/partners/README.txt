Logo files used by the home-page carousel and the integrations hub.
whatsapp.svg, gmail.svg, airtel-money.svg  = real brand marks (brand colours).
mpesa.svg, etims.svg, pesalink.svg, gok.svg = plain text wordmarks (placeholders).
To use the OFFICIAL logo, replace a file with the same name (SVG, transparent background).
Only use a logo if you are an authorised user of that brand and follow its brand guidelines.
