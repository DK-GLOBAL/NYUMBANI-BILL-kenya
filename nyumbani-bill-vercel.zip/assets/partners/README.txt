Drop the OFFICIAL logo files here (SVG, transparent background) with these exact names:
  mpesa.svg  etims.svg  gok.svg  whatsapp.svg  airtel-money.svg  pesalink.svg
The home-page carousel shows each file automatically and falls back to a neutral text badge when a file is missing.
Only add a logo if you are an authorised user of that brand and follow its brand guidelines.
