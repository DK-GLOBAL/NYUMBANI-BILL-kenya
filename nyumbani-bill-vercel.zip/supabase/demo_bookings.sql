-- Demo bookings: anyone can submit, only admins can read or update. Review before running.
create table if not exists public.demo_bookings(
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null check (char_length(name) between 2 and 100),
  phone text not null check (char_length(phone) between 9 and 20),
  email text check (email is null or char_length(email) <= 120),
  role text check (role is null or char_length(role) <= 60),
  apartments int check (apartments is null or apartments between 0 and 5000),
  county text check (county is null or char_length(county) <= 40),
  preferred_date date,
  preferred_time text check (preferred_time is null or char_length(preferred_time) <= 40),
  message text check (message is null or char_length(message) <= 500),
  status text not null default 'new' check (status in ('new','confirmed','done','cancelled'))
);
alter table public.demo_bookings enable row level security;
revoke all on public.demo_bookings from anon, authenticated;
grant insert on public.demo_bookings to anon, authenticated;
grant select, update on public.demo_bookings to authenticated;
drop policy if exists "anyone can book a demo" on public.demo_bookings;
create policy "anyone can book a demo" on public.demo_bookings for insert to anon, authenticated with check (status = 'new');
drop policy if exists "admins read bookings" on public.demo_bookings;
create policy "admins read bookings" on public.demo_bookings for select to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));
drop policy if exists "admins update bookings" on public.demo_bookings;
create policy "admins update bookings" on public.demo_bookings for update to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));
